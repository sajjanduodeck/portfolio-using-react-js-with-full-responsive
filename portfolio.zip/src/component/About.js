import React from "react";
import Common from "./Common";

function About() {
  return (
    <div>
      <Common
        name="Welcome to About page"
        visit="/Contact"
        btname="Contact Now"
      />
    </div>
  );
}

export default About;
