const CardData = [
  {
    imgsrc:
      "https://www.q5infotech.com/wp-content/uploads/2020/09/Web-Development.jpeg",
    title: "Web Development",
  },
  {
    imgsrc:
      "https://reliasoftware.com/static/9ce8aa204a21e69716018fee472b042c/the-complete-guide-to-mobile-app-development-2021.png",
    title: "App Development",
  },
  {
    imgsrc:
      "https://okcredit-blog-images-prod.storage.googleapis.com/2021/03/Software-Development-Business1--1-.jpg",
    title: "Software Development",
  },
  {
    imgsrc:
      "https://www.celebrityschool.in/blogs/wp-content/uploads/2022/07/Untitled-design-391.png",
    title: "Digital Marketing",
  },
  {
    imgsrc:
      "https://technofaq.org/wp-content/uploads/2018/08/android-app-development.jpg",
    title: "Android Development",
  },
  {
    imgsrc:
      "https://neilpatel.com/wp-content/uploads/2021/07/digital-marketing_featured-image.png",
    title: "Marketing",
  },
];

export default CardData;
